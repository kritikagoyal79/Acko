package com.acko.pagerduty.service;

import com.acko.pagerduty.DTO.response.AlertDTO;
import com.acko.pagerduty.Entity.Developer;
import com.acko.pagerduty.Entity.Team;
import com.acko.pagerduty.repositories.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

@Service
public class AlertService {
    @Autowired
    TeamRepository teamRepository;

    public AlertDTO findAndSendNotificationToDeveloper(long teamId) {
        Optional<Team> team = teamRepository.findById(teamId);
        if(team.isPresent()) {
            Team team1 = team.get();
            Map<Long, Developer> idDeveloper = new HashMap<>();
            for(Developer developer : team1.getDevelopers()) {
                idDeveloper.put(developer.getId(), developer);
            }
            //team1.getDevelopers().stream().filter(developer -> developer.isActive()).map().collect()
            Random random = new Random(team1.getDevelopers().get(0).getId());
            int num = random.nextInt();
            if(idDeveloper.containsKey(num)) {
                System.out.println("Send notification to developer" +idDeveloper.get(num));
            }
        }

        return new AlertDTO();
    }
}
