package com.acko.pagerduty.Entity;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
public class Team {
    @Column(name = "team_name")
    private String name;

    @Column(name = "team_id")
    @SequenceGenerator(name = "", initialValue = 1)
    private Long id;

    @OneToMany
    private List<Developer> developers;

    public void setId(Long id) {
        this.id = id;
    }

    @Id
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Developer> getDevelopers() {
        return developers;
    }

    public void setDevelopers(List<Developer> developers) {
        this.developers = developers;
    }
}
