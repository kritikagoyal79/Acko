package com.acko.pagerduty.repositories;

import com.acko.pagerduty.Entity.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team, Long> {
    public Team getTeamByName(String name);
}
