package com.acko.pagerduty.controller;

import com.acko.pagerduty.DTO.request.TeamDTO;
import com.acko.pagerduty.DTO.response.RegisterTeamDTO;
import com.acko.pagerduty.RegisterTeam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/team")
public class TeamController {

    @Autowired
    private RegisterTeam registerTeam;

    @PostMapping("/register")
    public RegisterTeamDTO registerTeam(@RequestBody TeamDTO teamDTO) {
        RegisterTeamDTO registerTeamDTO = registerTeam.registerTeam(teamDTO);
        return registerTeamDTO;
    }

}
