package com.acko.pagerduty.repositories;

import com.acko.pagerduty.Entity.Developer;
import com.acko.pagerduty.Entity.Team;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeveloperRepository extends JpaRepository<Developer, Long> {
   List<Developer> findAllByTeam(Team team);
}
