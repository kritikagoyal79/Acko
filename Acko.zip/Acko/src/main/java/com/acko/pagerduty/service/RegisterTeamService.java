package com.acko.pagerduty.service;

import com.acko.pagerduty.DTO.request.DeveloperDTO;
import com.acko.pagerduty.DTO.request.TeamDTO;
import com.acko.pagerduty.DTO.response.RegisterTeamDTO;
import com.acko.pagerduty.DTO.response.Status;
import com.acko.pagerduty.Entity.Developer;
import com.acko.pagerduty.Entity.Team;
import com.acko.pagerduty.repositories.DeveloperRepository;
import com.acko.pagerduty.repositories.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class RegisterTeamService {

    @Autowired
    TeamRepository teamRepository;

    @Transactional
    public RegisterTeamDTO registerTeam(TeamDTO teamDTO) {
        Team team = teamRepository.getTeamByName(teamDTO.getTeamName());
        //Team  newTeam = new Team();
        if(team == null) {
            team = new Team();
            team.setName(teamDTO.getTeamName());
            List<Developer> developerList = new ArrayList<>();
            for(DeveloperDTO developerDTO : teamDTO.getDevelopers()) {
                Developer developer = new Developer(developerDTO.getName(), developerDTO.getPhoneNumber());
                developerList.add(developer);
            }

            team = teamRepository.save(team);
        } else {
            //
        }

        //todo null check
        return new RegisterTeamDTO(team.getId(), new Status());
    }
}
