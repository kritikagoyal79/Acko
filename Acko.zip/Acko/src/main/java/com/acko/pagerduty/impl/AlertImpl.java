package com.acko.pagerduty.impl;

import com.acko.pagerduty.Alert;
import com.acko.pagerduty.DTO.response.AlertDTO;
import com.acko.pagerduty.service.AlertService;
import org.springframework.beans.factory.annotation.Autowired;

public class AlertImpl implements Alert {
    @Autowired
    private AlertService alertService;

    @Override
    public AlertDTO findAndSendNotificationToDeveloper(long teamId) {
        //validations
        return alertService.findAndSendNotificationToDeveloper(teamId);
    }
}
