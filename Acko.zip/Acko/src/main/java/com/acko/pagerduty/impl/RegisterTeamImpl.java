package com.acko.pagerduty.impl;

import com.acko.pagerduty.DTO.request.TeamDTO;
import com.acko.pagerduty.DTO.response.RegisterTeamDTO;
import com.acko.pagerduty.RegisterTeam;
import com.acko.pagerduty.service.RegisterTeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterTeamImpl implements RegisterTeam {

    @Autowired
    private RegisterTeamService registerTeamService;

    @Override
    public RegisterTeamDTO registerTeam(TeamDTO teamDTO) {
        //todo necessary validations

        return registerTeamService.registerTeam(teamDTO);
    }
}
