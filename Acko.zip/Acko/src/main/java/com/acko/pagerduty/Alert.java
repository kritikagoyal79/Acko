package com.acko.pagerduty;

import com.acko.pagerduty.DTO.request.TeamDTO;
import com.acko.pagerduty.DTO.response.AlertDTO;
import com.acko.pagerduty.DTO.response.RegisterTeamDTO;

public interface Alert {
    public AlertDTO findAndSendNotificationToDeveloper(long teamId);

}
