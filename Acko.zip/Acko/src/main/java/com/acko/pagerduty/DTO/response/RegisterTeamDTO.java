package com.acko.pagerduty.DTO.response;

public class RegisterTeamDTO {
    private Long teamId;
    private Status status;

    public RegisterTeamDTO(Long teamId, Status status) {
        this.teamId = teamId;
        this.status = status;
    }

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
