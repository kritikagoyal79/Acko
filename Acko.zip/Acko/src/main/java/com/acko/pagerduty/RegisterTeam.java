package com.acko.pagerduty;

import com.acko.pagerduty.DTO.request.TeamDTO;
import com.acko.pagerduty.DTO.response.RegisterTeamDTO;

public interface RegisterTeam {
    public RegisterTeamDTO registerTeam(TeamDTO teamDTO);
}
