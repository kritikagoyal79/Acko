package com.acko.pagerduty.DTO.request;

import java.util.List;

public class TeamDTO {
    private String teamName;
    private List<DeveloperDTO> developers;

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public List<DeveloperDTO> getDevelopers() {
        return developers;
    }

    public void setDevelopers(List<DeveloperDTO> developers) {
        this.developers = developers;
    }
}
