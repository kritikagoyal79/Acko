package com.acko.pagerduty.controller;

import com.acko.pagerduty.Alert;
import com.acko.pagerduty.DTO.response.AlertDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/alert")
public class AlertController {
    @Autowired
    private Alert alert;

    @GetMapping("/send/{teamId}")
    public AlertDTO assignDeveloperAndSendNotification(@PathVariable long teamId ) {
        AlertDTO alertDTO = alert.findAndSendNotificationToDeveloper(teamId);
        return alertDTO;
    }
}
